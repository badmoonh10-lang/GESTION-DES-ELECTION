# Déploiement TestElecteur sur Kali Linux

Guide pas à pas pour installer et faire fonctionner **DaveElection / TestElecteur** sur Kali Linux (Debian-based).

**Stack :** PHP 8+, Apache2, MariaDB/MySQL, Composer, FPDF

---

## Sommaire

1. [Corrections appliquées au projet](#1-corrections-appliquées-au-projet)
2. [Prérequis système](#2-prérequis-système)
3. [Étape 1 — Mise à jour du système](#3-étape-1--mise-à-jour-du-système)
4. [Étape 2 — Installation des paquets](#4-étape-2--installation-des-paquets)
5. [Étape 3 — Copie du projet](#5-étape-3--copie-du-projet)
6. [Étape 4 — Dépendances Composer (FPDF)](#6-étape-4--dépendances-composer-fpdf)
7. [Étape 5 — Base de données MySQL/MariaDB](#7-étape-5--base-de-données-mysqlmariadb)
8. [Étape 6 — Configuration de l'application](#8-étape-6--configuration-de-lapplication)
9. [Étape 7 — Dossiers storage et permissions](#9-étape-7--dossiers-storage-et-permissions)
10. [Étape 8 — VirtualHost Apache](#10-étape-8--virtualhost-apache)
11. [Étape 9 — Vérification (smoke test)](#11-étape-9--vérification-smoke-test)
12. [Étape 10 — Accès navigateur](#12-étape-10--accès-navigateur)
13. [Commandes utiles (référence rapide)](#13-commandes-utiles-référence-rapide)
14. [Dépannage](#14-dépannage)

---

## 1. Corrections appliquées au projet

Les problèmes suivants ont été corrigés :

| Problème | Correction |
|----------|------------|
| FPDF absent (`composer.json` vide) | Ajout de `setasign/fpdf ^1.8` + `composer install` |
| Import invalide `use FPDF\FPDF` dans `card.php` | Suppression de l'import incorrect |
| `agents_official_pdf.php` sans vérif autoload | Ajout du contrôle FPDF avant chargement |
| Dossier `storage/qr/` manquant | Création automatique dans `bootstrap.php` |
| Image `signature.png` absente | Script `scripts/create_signature.php` |
| Fichiers `vendor/composer.json` erronés | Suppression (conflit avec le vrai `composer.json`) |

---

## 2. Prérequis système

| Composant | Version |
|-----------|---------|
| Kali Linux | Rolling (2024+) |
| PHP | 8.0 ou plus |
| MariaDB / MySQL | 10.x / 8.x |
| Apache2 | 2.4+ |
| Composer | 2.x |

**Extensions PHP requises :** `pdo_mysql`, `mbstring`, `fileinfo`, `curl`, `gd` (recommandé pour images/QR)

---

## 3. Étape 1 — Mise à jour du système

```bash
sudo apt update
sudo apt upgrade -y
```

---

## 4. Étape 2 — Installation des paquets

```bash
sudo apt install -y \
  apache2 \
  mariadb-server \
  php \
  php-cli \
  php-mysql \
  php-mbstring \
  php-xml \
  php-curl \
  php-gd \
  php-zip \
  php-fileinfo \
  unzip \
  git \
  composer
```

Démarrer et activer les services :

```bash
sudo systemctl enable apache2
sudo systemctl enable mariadb
sudo systemctl start apache2
sudo systemctl start mariadb
```

Vérifier PHP :

```bash
php -v
php -m | grep -E 'pdo_mysql|mbstring|gd|curl|fileinfo'
```

---

## 5. Étape 3 — Copie du projet

### Option A — Depuis une clé USB / archive

```bash
sudo mkdir -p /var/www
sudo cp -r /chemin/vers/TestElecteur /var/www/TestElecteur
sudo chown -R www-data:www-data /var/www/TestElecteur
```

### Option B — Depuis Git (si dépôt disponible)

```bash
cd /var/www
sudo git clone <URL_DU_DEPOT> TestElecteur
sudo chown -R www-data:www-data TestElecteur
```

Aller dans le dossier du projet :

```bash
cd /var/www/TestElecteur
```

---

## 6. Étape 4 — Dépendances Composer (FPDF)

```bash
cd /var/www/TestElecteur
composer install --no-dev --optimize-autoloader
```

Si `composer` n'est pas installé globalement :

```bash
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer
composer install --no-dev --optimize-autoloader
```

Vérifier FPDF :

```bash
php -r "require 'vendor/autoload.php'; echo class_exists('FPDF') ? 'FPDF OK' : 'FPDF MANQUANT';"
```

---

## 7. Étape 5 — Base de données MySQL/MariaDB

### Sécuriser MariaDB (première installation)

```bash
sudo mysql_secure_installation
```

### Créer la base et l'utilisateur

```bash
sudo mysql -u root -p
```

Dans le shell MySQL :

```sql
CREATE DATABASE TestElecteur CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'testelecteur'@'localhost' IDENTIFIED BY 'MotDePasseFort123!';
GRANT ALL PRIVILEGES ON TestElecteur.* TO 'testelecteur'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### Importer le schéma

```bash
cd /var/www/TestElecteur
mysql -u testelecteur -p TestElecteur < EnrolemetElecteur.sql
```

> Si vous mettez à jour une base existante :

```bash
mysql -u testelecteur -p TestElecteur < scripts/migrate_v2.sql
```

---

## 8. Étape 6 — Configuration de l'application

Éditer `config/config.php` :

```bash
sudo nano /var/www/TestElecteur/config/config.php
```

Contenu adapté à Kali (Apache avec alias `/TestElecteur/public`) :

```php
<?php
return [
    'db' => [
        'host' => '127.0.0.1',
        'name' => 'TestElecteur',
        'user' => 'testelecteur',
        'pass' => 'MotDePasseFort123!',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'base_url' => '/TestElecteur/public',
        'upload_dir' => __DIR__ . '/../storage/uploads',
    ],
];
```

> Si vous configurez le VirtualHost avec `DocumentRoot` sur `public/` (recommandé), utilisez `'base_url' => ''`.

---

## 9. Étape 7 — Dossiers storage et permissions

```bash
cd /var/www/TestElecteur
mkdir -p storage/uploads storage/backups storage/qr public/assets/img
php scripts/create_signature.php
sudo chown -R www-data:www-data storage public/assets/img
sudo chmod -R 775 storage
```

---

## 10. Étape 8 — VirtualHost Apache

### Option recommandée — DocumentRoot sur `public/`

Créer le fichier de site :

```bash
sudo nano /etc/apache2/sites-available/testelecteur.conf
```

Contenu :

```apache
<VirtualHost *:80>
    ServerName testelecteur.local
    DocumentRoot /var/www/TestElecteur/public

    <Directory /var/www/TestElecteur/public>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/testelecteur_error.log
    CustomLog ${APACHE_LOG_DIR}/testelecteur_access.log combined
</VirtualHost>
```

Activer le site et les modules :

```bash
sudo a2ensite testelecteur.conf
sudo a2enmod rewrite
sudo a2dissite 000-default.conf
sudo systemctl reload apache2
```

Ajouter dans `/etc/hosts` (optionnel, pour un nom local) :

```bash
echo "127.0.0.1 testelecteur.local" | sudo tee -a /etc/hosts
```

Dans ce cas, mettre `'base_url' => ''` dans `config/config.php`.

### Option alternative — Sous-dossier dans htdocs

```bash
sudo ln -s /var/www/TestElecteur /var/www/html/TestElecteur
```

Accès : `http://localhost/TestElecteur/public/`  
`base_url` : `/TestElecteur/public`

---

## 11. Étape 9 — Vérification (smoke test)

```bash
cd /var/www/TestElecteur
php scripts/smoke_test.php
```

Résultat attendu :

```
DB OK - 3 utilisateur(s)
FPDF OK
SMOKE TEST PASSED
```

Test HTTP :

```bash
curl -I http://localhost/login.php
# ou avec VirtualHost :
curl -I http://testelecteur.local/login.php
```

---

## 12. Étape 10 — Accès navigateur

Ouvrir dans le navigateur :

| Configuration | URL |
|---------------|-----|
| VirtualHost (DocumentRoot = public) | `http://testelecteur.local/` |
| Sous-dossier Apache | `http://localhost/TestElecteur/public/` |

### Comptes de démonstration

| Rôle | Identifiant | Mot de passe |
|------|-------------|--------------|
| Direction | `direction` | `direction123` |
| Agent de terrain | `agent` | `agent123` |
| Électeur | `electeur` | `electeur123` |

> Changez ces mots de passe avant toute utilisation en production.

---

## 13. Commandes utiles (référence rapide)

```bash
# Mise à jour système
sudo apt update && sudo apt upgrade -y

# Installation complète des dépendances
sudo apt install -y apache2 mariadb-server php php-cli php-mysql php-mbstring php-xml php-curl php-gd php-zip php-fileinfo unzip git composer

# Services
sudo systemctl start apache2 mariadb
sudo systemctl enable apache2 mariadb
sudo systemctl status apache2
sudo systemctl status mariadb

# Projet
cd /var/www/TestElecteur
composer install --no-dev --optimize-autoloader
composer require setasign/fpdf

# Base de données
sudo mysql -u root -p
mysql -u testelecteur -p TestElecteur < EnrolemetElecteur.sql
mysql -u testelecteur -p TestElecteur < scripts/migrate_v2.sql

# Permissions
sudo chown -R www-data:www-data /var/www/TestElecteur
sudo chmod -R 775 /var/www/TestElecteur/storage
mkdir -p storage/uploads storage/backups storage/qr
php scripts/create_signature.php

# Apache
sudo a2ensite testelecteur.conf
sudo a2enmod rewrite
sudo systemctl reload apache2
sudo tail -f /var/log/apache2/testelecteur_error.log

# Tests
php scripts/smoke_test.php
php -l public/login.php
curl -I http://localhost/TestElecteur/public/login.php

# Serveur PHP intégré (test rapide sans Apache)
cd /var/www/TestElecteur
php -S localhost:8000 -t public
# → http://localhost:8000/  (base_url = '')
```

---

## 14. Dépannage

### Erreur « FPDF non installé »

```bash
cd /var/www/TestElecteur
composer install
php -r "require 'vendor/autoload.php'; var_dump(class_exists('FPDF'));"
```

### Erreur « could not find driver » (PDO MySQL)

```bash
sudo apt install php-mysql
sudo systemctl restart apache2
php -m | grep pdo_mysql
```

### Page blanche / erreur 500

```bash
sudo tail -50 /var/log/apache2/error.log
php -v
```

Activer temporairement les erreurs dans `public/index.php` (dev uniquement) :

```php
ini_set('display_errors', '1');
error_reporting(E_ALL);
```

### Connexion base de données refusée

- Vérifier `host`, `name`, `user`, `pass` dans `config/config.php`
- Tester : `mysql -u testelecteur -p TestElecteur -e "SELECT COUNT(*) FROM users;"`

### Uploads / sauvegardes impossibles

```bash
sudo chown -R www-data:www-data storage
sudo chmod -R 775 storage
ls -la storage/
```

### Liens CSS/JS cassés

Ajuster `base_url` dans `config/config.php` :
- Racine du site : `''`
- Sous-dossier : `/TestElecteur/public`

### QR code absent sur les cartes PDF

Le système utilise (dans l'ordre) : bibliothèques PHP QR, API externe, script Python.  
Installer `php-gd` et `python3` améliore les chances :

```bash
sudo apt install php-gd python3
```

### Extension GD manquante

```bash
sudo apt install php-gd
sudo systemctl restart apache2
php scripts/create_signature.php
```

---

## Structure des dossiers importants

```
/var/www/TestElecteur/
├── app/              # Logique métier
├── config/           # config.php (DB, base_url)
├── public/           # Point d'entrée web (DocumentRoot)
├── storage/
│   ├── uploads/      # Photos uploadées
│   ├── backups/      # Sauvegardes XML
│   └── qr/           # QR codes générés
├── scripts/
│   ├── smoke_test.php
│   ├── create_signature.php
│   └── migrate_v2.sql
├── vendor/           # FPDF (Composer)
└── EnrolemetElecteur.sql
```

---

*Projet éducatif — Activez HTTPS (certbot) et des mots de passe forts avant toute mise en production.*
