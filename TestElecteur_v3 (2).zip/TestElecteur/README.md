# DaveElection — Guide de déploiement

Mini système d'enrôlement des électeurs, de gestion des agents de terrain et de vote en ligne / physique.

**Stack :** PHP 8+, MySQL, Bootstrap 5, FPDF (Composer)

---

## Sommaire

1. [Prérequis](#1-prérequis)
2. [Déploiement en local (Windows — WAMP)](#2-déploiement-en-local-windows--wamp)
3. [Déploiement en local (alternatives)](#3-déploiement-en-local-alternatives)
4. [Hébergement gratuit à long terme](#4-hébergement-gratuit-à-long-terme)
5. [Configuration de l'application](#5-configuration-de-lapplication)
6. [Comptes de démonstration](#6-comptes-de-démonstration)
7. [Dépannage](#7-dépannage)

---

## 1. Prérequis

| Composant | Version minimale |
|-----------|------------------|
| PHP | 8.0 ou plus |
| MySQL / MariaDB | 5.7 / 10.x |
| Composer | 2.x |
| Extensions PHP | `pdo_mysql`, `mbstring`, `fileinfo`, `gd` (recommandé pour images) |

---

## 2. Déploiement en local (Windows — WAMP)

### Étape 1 — Installer WAMP

1. Téléchargez [WampServer](https://www.wampserver.com/) et installez-le.
2. Démarrez WAMP : l'icône doit devenir **verte**.
3. Vérifiez PHP : ouvrez `http://localhost` dans le navigateur.

### Étape 2 — Copier le projet

1. Copiez le dossier `TestElecteur` dans le répertoire web de WAMP :

   ```
   C:\wamp64\www\TestElecteur
   ```

   > Adaptez si votre installation WAMP est ailleurs (`C:\wamp\www\` sur les anciennes versions).

### Étape 3 — Installer les dépendances PHP

Ouvrez un terminal dans le dossier du projet :

```bash
cd C:\wamp64\www\TestElecteur
composer install
```

Si `composer` n'est pas reconnu, installez-le depuis [getcomposer.org](https://getcomposer.org/download/).

### Étape 4 — Créer la base de données

1. Ouvrez **phpMyAdmin** : `http://localhost/phpmyadmin`
2. Créez une base nommée **`TestElecteur`** (interclassement : `utf8mb4_unicode_ci`).
3. Sélectionnez la base → onglet **Importer**.
4. Importez le fichier **`EnrolemetElecteur.sql`** à la racine du projet.

> Si vous mettez à jour une base déjà existante, exécutez aussi **`scripts/migrate_v2.sql`**.

### Étape 5 — Configurer l'application

Éditez **`config/config.php`** :

```php
return [
    'db' => [
        'host' => '127.0.0.1',
        'name' => 'TestElecteur',
        'user' => 'root',
        'pass' => '',          // mot de passe MySQL WAMP (souvent vide)
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'base_url' => '/TestElecteur/public',
        'upload_dir' => __DIR__ . '/../storage/uploads',
    ],
];
```

### Étape 6 — Droits d'écriture

Assurez-vous que ces dossiers existent et sont **inscriptibles** par Apache :

```
storage/uploads/
storage/backups/
storage/qr/
```

Sous Windows/WAMP, les droits sont en général accordés automatiquement. En cas d'erreur d'upload, donnez les droits **Modifier** à l'utilisateur `Everyone` ou `IUSR` sur le dossier `storage/`.

### Étape 7 — Tester l'application

Ouvrez dans le navigateur :

```
http://localhost/TestElecteur/public/
```

Connexion avec un compte démo (voir [section 6](#6-comptes-de-démonstration)).

---

## 3. Déploiement en local (alternatives)

### XAMPP (Windows / macOS / Linux)

Même procédure que WAMP, en plaçant le projet dans :

- Windows : `C:\xampp\htdocs\TestElecteur`
- Linux : `/opt/lampp/htdocs/TestElecteur`

`base_url` : `/TestElecteur/public`

### Laragon (Windows)

Placez le projet dans `C:\laragon\www\TestElecteur`.  
`base_url` : `/TestElecteur/public`

### PHP intégré (test rapide)

```bash
cd TestElecteur
composer install
php -S localhost:8000 -t public
```

Dans `config/config.php` :

```php
'base_url' => '',
```

Accès : `http://localhost:8000/`

---

## 4. Hébergement gratuit à long terme

### Option recommandée : InfinityFree

[InfinityFree](https://www.infinityfree.com/) propose de l'hébergement PHP + MySQL **gratuit et sans limite de durée** (avec quelques contraintes : pas de cron, bande passante limitée, nom de domaine en sous-domaine `.infinityfreeapp.com` ou domaine personnalisé).

#### Étape 1 — Créer un compte

1. Inscrivez-vous sur [infinityfree.com](https://www.infinityfree.com/).
2. Créez un **compte d'hébergement** (Hosting Account).
3. Notez votre **sous-domaine** (ex. `daveelection.infinityfreeapp.com`).

#### Étape 2 — Créer la base MySQL

1. Dans le panneau **Control Panel** → **MySQL Databases**.
2. Créez une base et un utilisateur MySQL.
3. Notez :
   - Hôte MySQL (ex. `sql123.infinityfree.com`, **pas** `localhost`)
   - Nom de la base
   - Utilisateur
   - Mot de passe

#### Étape 3 — Transférer les fichiers

**Méthode FTP (FileZilla) :**

1. Récupérez les identifiants FTP dans le panneau InfinityFree.
2. Connectez-vous avec [FileZilla](https://filezilla-project.org/).
3. Uploadez **tout le contenu** du projet dans `htdocs/` (ou le dossier racine de votre compte).

**Structure recommandée sur l'hébergeur :**

```
htdocs/
├── app/
├── config/
├── public/          ← point d'entrée web
├── storage/
├── vendor/          ← après composer install en local, uploadez vendor/
├── EnrolemetElecteur.sql
└── composer.json
```

> **Astuce :** exécutez `composer install` **en local**, puis uploadez le dossier `vendor/` complet. La plupart des hébergeurs gratuits n'offrent pas SSH/Composer en ligne de commande.

#### Étape 4 — Importer la base de données

1. Panneau InfinityFree → **phpMyAdmin**.
2. Sélectionnez votre base → **Importer** → fichier `EnrolemetElecteur.sql`.

#### Étape 5 — Configurer `config/config.php`

```php
return [
    'db' => [
        'host' => 'sql123.infinityfree.com',   // votre hôte MySQL
        'name' => 'if0_xxxxxxxx_dave',         // nom de la base
        'user' => 'if0_xxxxxxxx',              // utilisateur MySQL
        'pass' => 'VOTRE_MOT_DE_PASSE',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'base_url' => '',   // si le site est à la racine du domaine
        'upload_dir' => __DIR__ . '/../storage/uploads',
    ],
];
```

**Si vous ne pouvez pas pointer le domaine vers `public/`**, deux solutions :

**A — Rediriger la racine vers `public/`** (fichier `htdocs/index.php`) :

```php
<?php
header('Location: /public/');
exit;
```

**B — Déplacer le contenu de `public/` à la racine `htdocs/`** et ajuster les chemins `require_once` (plus complexe, non recommandé).

**Meilleure solution :** dans le panneau InfinityFree, définir le **Document Root** sur le dossier `public` si l'option est disponible.

Avec document root = `public/` :

```php
'base_url' => '',
```

URL d'accès : `https://votre-site.infinityfreeapp.com/`

#### Étape 6 — Permissions

Via le gestionnaire de fichiers du panneau, vérifiez que `storage/uploads`, `storage/backups` et `storage/qr` sont inscriptibles (chmod **755** ou **775**).

#### Étape 7 — Vérification

1. Ouvrez l'URL de votre site.
2. Connectez-vous avec `direction` / `direction123`.
3. Testez un pré-enrôlement et la génération d'une carte PDF.

---

### Autres plateformes gratuites (long terme)

| Plateforme | Avantages | Limites |
|------------|-----------|---------|
| **[InfinityFree](https://www.infinityfree.com/)** | PHP + MySQL, gratuit sans expiration, sous-domaine gratuit | Pas de SSH, performances modérées |
| **[000webhost](https://www.000webhost.com/)** | PHP + MySQL, interface simple | Compte inactif supprimé après ~3 mois sans visite |
| **[AlwaysData](https://www.alwaysdata.com/)** (offre gratuite) | Stable, support français | 100 Mo disque, 1 base MySQL |
| **[Oracle Cloud Always Free](https://www.oracle.com/cloud/free/)** | VPS gratuit durable, contrôle total | Configuration avancée (Linux, Apache/Nginx, SSL) |

#### Oracle Cloud (avancé — vraiment durable)

Pour un déploiement professionnel gratuit à long terme :

1. Créez une VM **Always Free** (Ubuntu).
2. Installez : `apache2`, `php8.x`, `mysql`, `composer`.
3. Clonez/uploadez le projet dans `/var/www/daveelection`.
4. Configurez le VirtualHost avec `DocumentRoot /var/www/daveelection/public`.
5. Activez HTTPS avec **Let's Encrypt** (`certbot`).

---

## 5. Configuration de l'application

### Fichier principal : `config/config.php`

| Paramètre | Description | Exemple local | Exemple hébergement |
|-----------|-------------|---------------|---------------------|
| `db.host` | Serveur MySQL | `127.0.0.1` | `sql123.infinityfree.com` |
| `db.name` | Nom de la base | `TestElecteur` | `if0_xxx_dave` |
| `db.user` | Utilisateur MySQL | `root` | `if0_xxx` |
| `db.pass` | Mot de passe | `''` | votre mot de passe |
| `app.base_url` | Chemin URL public (sans domaine) | `/TestElecteur/public` | `''` |

### Dossiers à protéger

Ne rendez **pas** accessibles depuis le web (en dehors de `public/`) :

- `config/`
- `app/`
- `storage/` (sauf via `media.php` pour les images autorisées)
- `vendor/`

Le point d'entrée unique doit être le dossier **`public/`**.

### Dépendances Composer

```bash
composer install
```

Package requis : `setasign/fpdf` (génération des cartes et listes PDF).

### Migrations

| Fichier | Usage |
|---------|-------|
| `EnrolemetElecteur.sql` | Installation complète (nouvelle base) |
| `scripts/migrate_v2.sql` | Mise à jour d'une base existante (agents, votes physiques) |

---

## 6. Comptes de démonstration

| Rôle | Identifiant | Mot de passe |
|------|-------------|--------------|
| Direction | `direction` | `direction123` |
| Agent de terrain | `agent` | `agent123` |
| Électeur | `electeur` | `electeur123` |

> **Important :** changez ou supprimez ces comptes avant une mise en production réelle.

---

## 7. Dépannage

### Erreur « FPDF non installé »

```bash
composer install
```

Vérifiez que le dossier `vendor/` est bien présent sur l'hébergeur.

### Page blanche ou erreur 500

- Activez l'affichage des erreurs PHP temporairement.
- Vérifiez la version PHP (≥ 8.0).
- Consultez les logs Apache / du panneau d'hébergement.

### Erreur de connexion à la base de données

- Vérifiez `host`, `name`, `user`, `pass` dans `config/config.php`.
- Sur l'hébergement gratuit, l'hôte MySQL est **rarement** `localhost` ou `127.0.0.1`.

### Images / uploads ne fonctionnent pas

- Vérifiez les droits d'écriture sur `storage/uploads/`.
- Vérifiez que `upload_max_filesize` et `post_max_size` dans `php.ini` sont suffisants (ex. 8M).

### Liens cassés (CSS, pages)

- Ajustez `base_url` dans `config/config.php` selon votre URL réelle.
- Local WAMP : `/TestElecteur/public`
- Racine du domaine : `''` (chaîne vide)

### QR code indisponible sur les cartes

Le système tente plusieurs méthodes (bibliothèques PHP, API, script Python). Sur un hébergement gratuit sans Python ni extensions QR, le PDF reste généré mais le QR peut être absent — les informations textuelles de la carte restent valides.

### Sauvegardes XML

Les fichiers sont stockés dans `storage/backups/`. Consultez-les depuis **Dashboard Direction → Sauvegardes XML**.

---

## Structure du projet

```
TestElecteur/
├── app/                 # Logique métier (auth, helpers, backup)
├── config/              # Configuration (DB, base_url)
├── public/              # Point d'entrée web (DocumentRoot)
│   ├── direction/       # Espace Direction
│   ├── agent/           # Espace Agent de terrain
│   ├── elector/         # Espace Électeur
│   └── assets/          # CSS, JS, images
├── storage/
│   ├── uploads/         # Photos et pièces jointes
│   ├── backups/         # Sauvegardes XML
│   └── qr/              # QR codes générés
├── scripts/             # Migrations SQL, utilitaires
├── vendor/              # Dépendances Composer
├── EnrolemetElecteur.sql
└── composer.json
```

---

## Licence et usage

Projet éducatif / démonstration. Adaptez la configuration et la sécurité avant tout usage en production réelle (HTTPS, mots de passe forts, suppression des comptes démo).
